<?php
/** 
 * 
 * electrothemenewproducts.php
 * 
 * Language file for front page.
 * 
*/
$_['heading_title']             = 'Electro Theme - New Products';
$_['text_new_products']         = 'Новые товары';
$_['text_all']                  = 'Все категории';